ROULETTE ANALYZER — prototype v0.1

Fichiers :
- index.html : application mobile web
- manifest.json : configuration PWA
- sw.js : cache hors ligne basique

Démarrage :
1. Ouvrir index.html dans un navigateur pour tester l'interface.
2. Pour l'installation PWA sur iPhone, héberger les fichiers sur un site HTTPS.
3. Dans Safari sur iPhone : Partager > Ajouter à l'écran d'accueil.

Limites :
- Cette version n'est PAS connectée à MyStake et n'accède à aucune donnée en direct.
- La connexion réelle nécessite une API/flux officiellement autorisé et sa documentation.
- Les résultats de démonstration sont modifiables manuellement.
- Elle ne prédit pas le prochain numéro/couleur et ne garantit aucun gain.
- Ne jamais fournir mot de passe, cookies ou jetons de session MyStake à une application non officielle.
